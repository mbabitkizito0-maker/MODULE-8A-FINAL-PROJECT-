#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

// One entry from the assignment input file.
struct Point {
    int x;       // horizontal coordinate
    string ch;   // block character: █ or ░
    int y;       // vertical coordinate
};

int main() {
    // Data copied from "M08 Final Project InputData.docx".
    // Each line is: x-coordinate, character, y-coordinate.
    const string inputData = R"DATA(
87 █ 3
23 ░ 2
61 █ 4
2 ░ 1
65 █ 4
31 ░ 5
30 ░ 6
20 █ 4
35 █ 1
2 █ 6
52 █ 1
12 █ 0
66 █ 6
69 █ 4
85 █ 0
55 █ 6
77 █ 3
9 █ 0
53 █ 6
5 █ 3
44 ░ 3
40 █ 3
14 █ 0
0 █ 5
60 ░ 0
14 █ 3
22 █ 1
26 █ 6
66 █ 2
29 █ 5
8 █ 0
80 ░ 5
34 █ 5
8 ░ 3
87 █ 1
47 █ 6
6 █ 0
45 █ 1
45 █ 2
29 █ 1
65 █ 6
52 █ 2
6 █ 3
2 ░ 4
58 █ 0
66 █ 1
16 █ 0
54 ░ 3
24 █ 6
67 ░ 1
9 █ 6
62 █ 2
44 █ 0
21 █ 4
62 ░ 5
15 █ 6
0 █ 0
4 █ 0
70 █ 2
63 ░ 4
78 █ 1
81 █ 0
87 ░ 0
2 ░ 2
16 ░ 4
36 ░ 4
43 █ 3
68 █ 2
18 ░ 6
4 █ 3
62 █ 3
30 ░ 0
79 █ 1
75 ░ 6
53 █ 4
24 █ 0
54 ░ 2
22 ░ 3
79 █ 5
67 ░ 6
25 █ 0
56 █ 0
87 █ 4
2 █ 3
1 █ 0
55 █ 0
72 █ 1
79 ░ 4
42 █ 3
37 ░ 2
79 ░ 2
22 █ 4
88 █ 4
1 █ 1
46 █ 4
66 █ 3
30 █ 5
14 █ 1
39 █ 3
67 ░ 2
1 █ 5
89 ░ 1
46 ░ 0
70 █ 1
35 █ 3
73 ░ 5
7 █ 3
52 █ 0
81 █ 6
47 ░ 1
38 ░ 0
78 █ 4
54 ░ 4
53 █ 5
38 █ 1
15 █ 5
66 █ 4
31 ░ 1
33 █ 6
43 █ 4
34 █ 3
80 █ 6
82 █ 6
65 █ 5
67 ░ 0
25 █ 6
44 ░ 2
36 █ 2
21 █ 2
75 ░ 0
86 █ 0
18 ░ 0
46 █ 3
73 █ 0
7 █ 0
72 █ 5
53 █ 1
17 █ 0
34 █ 6
54 █ 6
41 █ 4
0 █ 4
23 █ 5
60 █ 1
15 █ 2
83 █ 6
73 █ 6
62 █ 4
89 ░ 3
86 █ 6
49 ░ 4
86 █ 5
63 ░ 3
73 ░ 1
2 ░ 5
16 ░ 5
67 ░ 4
30 █ 1
10 ░ 0
15 █ 1
7 █ 6
61 █ 5
61 █ 1
83 █ 0
36 █ 0
39 ░ 1
50 ░ 6
47 █ 4
71 █ 5
56 █ 6
14 █ 4
78 █ 3
21 █ 5
8 █ 6
66 █ 5
52 █ 3
22 █ 5
42 █ 4
13 █ 0
6 █ 6
43 █ 2
65 █ 2
44 █ 1
29 █ 0
67 ░ 5
23 ░ 4
24 ░ 1
60 █ 5
66 █ 0
44 ░ 4
39 █ 2
88 █ 2
4 █ 6
52 █ 6
48 █ 6
45 █ 0
5 █ 0
79 █ 6
35 █ 5
27 █ 6
57 █ 6
84 █ 0
22 █ 2
0 █ 3
33 █ 5
74 █ 6
58 █ 6
39 █ 4
87 ░ 6
24 ░ 5
1 █ 3
46 █ 2
89 ░ 5
3 █ 3
5 █ 6
43 ░ 5
42 █ 2
41 █ 5
28 █ 6
61 █ 2
38 █ 2
87 █ 5
68 █ 4
10 ░ 6
16 █ 6
14 █ 5
0 █ 6
37 ░ 3
89 ░ 2
48 ░ 3
17 █ 6
36 █ 3
48 █ 4
46 █ 1
59 █ 6
52 █ 5
77 █ 1
35 ░ 6
74 █ 0
35 █ 2
15 █ 3
72 █ 0
23 █ 0
79 ░ 3
49 ░ 5
23 █ 1
82 █ 0
21 █ 3
20 █ 3
59 █ 0
54 ░ 1
36 ░ 5
12 █ 6
89 ░ 4
86 █ 1
57 █ 0
14 █ 2
65 █ 0
78 █ 2
42 █ 5
29 █ 6
16 ░ 3
1 █ 6
80 █ 0
65 █ 3
37 █ 1
54 ░ 5
70 █ 4
84 █ 6
40 ░ 2
88 █ 3
47 █ 3
23 █ 6
28 █ 0
15 █ 0
77 █ 4
53 █ 2
35 █ 4
1 █ 4
87 █ 2
88 █ 1
34 █ 4
47 ░ 2
54 █ 0
78 █ 5
0 █ 1
61 █ 3
20 █ 2
69 ░ 3
62 ░ 1
63 ░ 2
67 █ 3
72 █ 6
36 █ 1
0 █ 2
41 ░ 3
49 █ 6
14 █ 6
15 █ 4
47 █ 5
2 █ 0
88 █ 5
43 █ 1
26 █ 0
71 ░ 4
71 █ 1
53 █ 0
16 ░ 2
40 █ 5
77 █ 5
3 █ 0
37 █ 0
53 █ 3
65 █ 1
77 █ 2
70 █ 5
79 █ 0
68 █ 3
3 █ 6
60 ░ 6
52 █ 4
80 ░ 1
13 █ 6
16 ░ 1
48 █ 5
85 █ 6
40 █ 4
21 █ 1
71 ░ 2
69 █ 2
1 █ 2
27 █ 0
)DATA";

    // Step 1: Parse the supplied input data.
    istringstream input(inputData);
    vector<Point> points;
    int x, y;
    string ch;

    while (input >> x >> ch >> y) {
        points.push_back({x, ch, y});
    }

    if (points.empty()) {
        cerr << "Error: no input data was loaded." << endl;
        return 1;
    }

    // Step 2: Find the largest x and y coordinates.
    int maxX = 0;
    int maxY = 0;
    for (const Point& p : points) {
        maxX = max(maxX, p.x);
        maxY = max(maxY, p.y);
    }

    // Step 3: Make a 2D grid, initially filled with spaces.
    // Rows represent y; columns represent x.
    vector<vector<string>> grid(
        maxY + 1, vector<string>(maxX + 1, " ")
    );

    // Step 4: Put each input character at its coordinate.
    for (const Point& p : points) {
        grid[p.y][p.x] = p.ch;
    }

    // Step 5: Print the grid. Keep a monospace font for best alignment.
    cout << "REVEALED OUTPUT" << endl << endl;
    for (int row = 0; row <= maxY; ++row) {
        for (int col = 0; col <= maxX; ++col) {
            cout << grid[row][col];
        }
        cout << endl;
    }
    cout << endl << "Points processed: " << points.size() << endl;
    cout << "Grid size: " << (maxX + 1) << " columns x "
         << (maxY + 1) << " rows" << endl;
    return 0;
}
